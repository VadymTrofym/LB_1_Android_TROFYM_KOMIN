package com.example.lb_1_please_work;

public class Model {

    private boolean isSelected;
    private String good;
    private String goodNumber;

    public String getGood() {
        return good;
    }

    public void setGood(String good) {
        this.good = good;
    }

    public boolean getSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getGoodNumber() {return goodNumber; }

    public void setGoodNumber(String goodNumber) {this.goodNumber = goodNumber; }
}
