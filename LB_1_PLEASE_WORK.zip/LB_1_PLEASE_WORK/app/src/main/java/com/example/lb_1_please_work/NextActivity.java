package com.example.lb_1_please_work;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class NextActivity extends AppCompatActivity {

    private TextView tv;
    private  TextView numberOfgood;
    private TextView row_calc;
    private int r = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
        tv = findViewById(R.id.tv);
        numberOfgood=findViewById(R.id.numberOfgood);
        row_calc=findViewById(R.id.row_calc);
        for (int i = 0; i < CustomAdapter.modelArrayList.size(); i++){

            if(CustomAdapter.modelArrayList.get(i).getSelected()) {
                tv.setText(tv.getText() + " "+ CustomAdapter.modelArrayList.get(i).getGood()+"\n");
                numberOfgood.setText(numberOfgood.getText() + " "+ CustomAdapter.modelArrayList.get(i).getGoodNumber()+"\n");
                r++;

            }

        }
        row_calc.setText((row_calc.getText()+" "+r+" товара(ов)"));


    }


}
